import pygame

player_model = pygame.image.load("./global_assets/local_player_model.png")
