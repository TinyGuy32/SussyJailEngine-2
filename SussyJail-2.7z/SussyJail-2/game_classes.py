import pygame

# TODO: create a class that contains all the shared logic between Player and SolidObject

class Player:
    def __init__(self, screen, image, x_vel, y_vel):
        self.vel = [x_vel, y_vel]
        self.x = 0
        self.y = 0
        self.screen = screen
        self.image = image

    def step(self, check):
        # the check paramater will be used to check if the player should move or if there is something preventing it
        if check:
            self.x += self.vel[0]
            self.y += self.vel[1]

    def calculate_draw_location(self):
        screen_width, screen_height = pygame.display.get_surface().get_size()
        #draw_x = round((screen_width/2)-(self.image.get_width()/2))
        #draw_y = round((screen_height/2)-(self.image.get_height()/2))
        draw_x = round((screen_width/2))
        draw_y = round((screen_height/2))
        return (draw_x, draw_y)

    def draw(self):
        # this function should draw the player in the midle of the screen
        draw_cord = self.calculate_draw_location()
        self.screen.blit(self.image, draw_cord)

# this is mainly just a container for information about the object
class SolidObject:
    def __init__(self, screen, image, x, y):
        # replace with a list [x, y]
        self.x = x
        self.y = y
        self.image = image
        self.screen = screen
        
    # checks if the player will be inside the object after their next step
    def player_inside_after_step(self, player):
        new_player_location = (player.x+player.vel[0], player.y+player.vel[1])

        within_width = ( new_player_location[0] > self.x and new_player_location[0] < self.x+(self.image.get_width()) ) or ( new_player_location[0]+player.image.get_width() > self.x and new_player_location[0]+player.image.get_width() < (self.x+self.image.get_width()) )
        within_height = ( new_player_location[1] > self.y and new_player_location[1] < self.y+(self.image.get_height()) ) or ( new_player_location[1]+player.image.get_height() > self.y and new_player_location[1]+player.image.get_height() < (self.y+self.image.get_height()) )
        
        return within_width and within_height
        
    def calculate_draw_location(self, player_location):
        player_x, player_y = player_location
        #draw_x = round(self.x-player_x+(self.screen.get_width()/2)-(self.image.get_width()/2))
        #draw_y = round(self.y-player_y+(self.screen.get_height()/2)-(self.image.get_height()/2))
        draw_x = round(self.x-player_x+(self.screen.get_width()/2))
        draw_y = round(self.y-player_y+(self.screen.get_height()/2))
        return (draw_x, draw_y)

    def draw(self, player_location):
        draw_cord = self.calculate_draw_location(player_location)
        self.screen.blit(self.image, draw_cord)

# makes it so that the cordinate lands on the centre of the image
def center_cordinate(image, cord):
    x = cord[0]+(image.get_width()/2)
    y = cord[1]+(image.get_height()/2)
    return (x, y)
