import pygame
import game_classes
import assets
import threading

threading_lock = threading.Lock()

# this is the window everything will be renderd on
screen = None

# the object representing the player should be placed here
player = None

# this should contain a list of things to be renderd
objects = None

#everything stops running when this becomes false
running = True
