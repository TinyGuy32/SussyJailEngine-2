import pygame
import game_classes
import global_data
import os

# this loads all the data in a folder, it should be compatable with the old SussyJail maps
def load_map(folder_path): # global_data.screen must be initialized before this runs
    listing = os.listdir(folder_path)
    for object in listing:
        load_object(f"{folder_path}/{object}")
    return listing

# loads every instance of an object into global_data.objects
def load_object(path):
    image = pygame.image.load(f"{path}/image.png")
    locations = open(f"{path}/config.txt").read().split("\n")

    index = 0
    while index < len(locations):
        locations[index] = interpret_cord(locations[index])
        index += 1

    for location in locations:
        new_object = game_classes.SolidObject(global_data.screen, image, location[0], location[1])
        global_data.objects.append(new_object)

# turns a string of the form "<x>_<y>" into a list of the form [x, y]
def interpret_cord(cord):
    numbers = cord.split("_")
    return [int(numbers[0]), int(numbers[1])]
