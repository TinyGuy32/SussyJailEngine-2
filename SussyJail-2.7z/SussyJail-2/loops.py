# this file contains the rendering loop, the input handling loop
# and the initialization function

import pygame
import assets
import global_data
import game_classes
import load_map
import sys
import time

def init_game():
    global_data.objects = []
    
    global_data.screen = pygame.display.set_mode((500, 500))
    global_data.player = game_classes.Player(global_data.screen, assets.player_model, 0, 0)

    # this loads the map into the global_data.objects list
    load_map.load_map(sys.argv[1])

# this will run as its own thread
def render_loop():
    global_data.screen.fill((0, 0, 0))
    
    global_data.threading_lock.acquire()
    player_location = (global_data.player.x, global_data.player.y)
    global_data.threading_lock.release()

    for solid_object in global_data.objects:
        draw_cord = solid_object.calculate_draw_location(player_location)
        within_screen_width = (draw_cord[0]+solid_object.image.get_width() > 0 and draw_cord[0] < global_data.screen.get_width())
        within_screen_height = (draw_cord[1]+solid_object.image.get_height() > 0 and draw_cord[1] < global_data.screen.get_height())
        if within_screen_width and within_screen_height:
            solid_object.draw(player_location)
    
    global_data.player.draw()
    pygame.display.flip()
    
#this handles input
def input_loop():
    time.sleep(0.005)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            global_data.running = False
        elif event.type == pygame.KEYDOWN:
            handle_key_down(event)
        elif event.type == pygame.KEYUP:
            handle_key_up(event)
    take_step = True
    for object in global_data.objects:
        if object.player_inside_after_step(global_data.player):
            take_step = False
            break
    global_data.player.step(take_step)

def handle_key_down(event):
    if event.key == pygame.K_d:
        global_data.player.vel[0] = 1
    if event.key == pygame.K_a:
        global_data.player.vel[0] = -1

    if event.key == pygame.K_w:
        global_data.player.vel[1] = -1
    if event.key == pygame.K_s:
        global_data.player.vel[1] = 1

def handle_key_up(event):
    if event.key == pygame.K_d or event.key == pygame.K_a:
        global_data.player.vel[0] = 0
    if event.key == pygame.K_w or event.key == pygame.K_s:
        global_data.player.vel[1] = 0
