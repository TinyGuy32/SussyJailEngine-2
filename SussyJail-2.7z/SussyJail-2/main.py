import pygame
import assets
import global_data
import game_classes
import loops
import thread_classes

def main():
    pygame.init()

    pygame.display.set_caption("SussyJailEngine-2")
    icon = pygame.image.load("icon.png")
    pygame.display.set_icon(icon)

    # initializes the variables in "global_data"
    loops.init_game()

    # creating the rendering loop
    render_thread = thread_classes.GameThread(loops.render_loop)
    render_thread.start()

    while global_data.running:
        loops.input_loop()
    
    render_thread.join()

if __name__ == "__main__":
    main()
