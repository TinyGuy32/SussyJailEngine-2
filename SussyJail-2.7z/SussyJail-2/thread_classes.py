# create a class for multithreading

import threading
import pygame
import global_data
import time

# GameThread threads run their function forever untill global_data.running becomes false
class GameThread(threading.Thread):
    def __init__(self, loop_function):
        threading.Thread.__init__(self)
        self.loop_function = loop_function
    def run(self):
        # looping the given function until global_data.running is false
        while global_data.running:
            #global_data.threading_lock.acquire()
            self.loop_function()
            #global_data.threading_lock.release()
